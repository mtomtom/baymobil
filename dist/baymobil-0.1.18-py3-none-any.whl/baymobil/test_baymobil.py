import pytest
import baymobil as baymob
import numpy as np

## Write our tests for the functions

## Main functions

## Simulations

## Plotting functions
